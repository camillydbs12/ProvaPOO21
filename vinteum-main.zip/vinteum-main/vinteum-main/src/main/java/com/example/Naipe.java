package com.example;

public enum Naipe {
    HEARTS,
    SPADES,
    DIAMONDS,
    CLUBS

}
