package com.example;

import java.util.ArrayList;

public class Jogador {
    private int pontos = 0;
    ArrayList<Carta> cartas =  new ArrayList<>();
    private boolean parou = false;


    public int getPontos() {
        return pontos;
    }
    
    public ArrayList<Carta> getCartas() {
        return cartas;
    }
   
    public boolean isParou() {
        return parou;
    
    }

    public void receberCarta(Carta carta ){ 
        cartas.add(carta);
        pontos += carta.getNumero();
    }

    public void parar(){
        parou = true;
        
    }


    
}
