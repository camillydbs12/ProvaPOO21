package com.example;

public class Jogo {
        Monte monte = new Monte();
        Jogador jogador = new Jogador();
        Computador computador = new Computador();

        public Jogo() {
        }

        public void distribuiCartaParaJogador(Jogador jogador){
            
        }

        
        
}
