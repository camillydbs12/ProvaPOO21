package com.example;


import java.util.ArrayList;
import java.util.Collections;

public class Monte {


    ArrayList<Carta> cartas = new ArrayList<>();
    
    public Monte() {
        for (int i = 1; i <= 13; i++) {
            Carta fistC = new Carta(i, Naipe.HEARTS);
            Carta secondC = new Carta(i, Naipe.SPADES);
            Carta thirdC = new Carta(i, Naipe.CLUBS);
            Carta fourthC = new Carta(i, Naipe.DIAMONDS);

            cartas.add(fistC);
            cartas.add(secondC);
            cartas.add(thirdC);
            cartas.add(fourthC);
            
        }
        
    }
    
    public void embaralhar(){
        
      Collections.shuffle(cartas);
    }

    public Carta virar(Carta carta) {
       return cartas.remove(0);

      
    }
}
